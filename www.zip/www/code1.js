gdjs.gameCode = {};
gdjs.gameCode.GDPlayerObjects1_1final = [];

gdjs.gameCode.forEachCount0_3 = 0;

gdjs.gameCode.forEachCount1_3 = 0;

gdjs.gameCode.forEachIndex3 = 0;

gdjs.gameCode.forEachObjects3 = [];

gdjs.gameCode.forEachTotalCount3 = 0;

gdjs.gameCode.GDPlayerObjects1= [];
gdjs.gameCode.GDPlayerObjects2= [];
gdjs.gameCode.GDPlayerObjects3= [];
gdjs.gameCode.GDPlatformObjects1= [];
gdjs.gameCode.GDPlatformObjects2= [];
gdjs.gameCode.GDPlatformObjects3= [];
gdjs.gameCode.GDJumpthruObjects1= [];
gdjs.gameCode.GDJumpthruObjects2= [];
gdjs.gameCode.GDJumpthruObjects3= [];
gdjs.gameCode.GDTiledGrassPlatformObjects1= [];
gdjs.gameCode.GDTiledGrassPlatformObjects2= [];
gdjs.gameCode.GDTiledGrassPlatformObjects3= [];
gdjs.gameCode.GDTiledCastlePlatformObjects1= [];
gdjs.gameCode.GDTiledCastlePlatformObjects2= [];
gdjs.gameCode.GDTiledCastlePlatformObjects3= [];
gdjs.gameCode.GDMovingPlatformObjects1= [];
gdjs.gameCode.GDMovingPlatformObjects2= [];
gdjs.gameCode.GDMovingPlatformObjects3= [];
gdjs.gameCode.GDGoLeftObjects1= [];
gdjs.gameCode.GDGoLeftObjects2= [];
gdjs.gameCode.GDGoLeftObjects3= [];
gdjs.gameCode.GDGoRightObjects1= [];
gdjs.gameCode.GDGoRightObjects2= [];
gdjs.gameCode.GDGoRightObjects3= [];
gdjs.gameCode.GDLadderObjects1= [];
gdjs.gameCode.GDLadderObjects2= [];
gdjs.gameCode.GDLadderObjects3= [];
gdjs.gameCode.GDPlayerHitBoxObjects1= [];
gdjs.gameCode.GDPlayerHitBoxObjects2= [];
gdjs.gameCode.GDPlayerHitBoxObjects3= [];
gdjs.gameCode.GDSlimeWalkObjects1= [];
gdjs.gameCode.GDSlimeWalkObjects2= [];
gdjs.gameCode.GDSlimeWalkObjects3= [];
gdjs.gameCode.GDFlyObjects1= [];
gdjs.gameCode.GDFlyObjects2= [];
gdjs.gameCode.GDFlyObjects3= [];
gdjs.gameCode.GDCloudObjects1= [];
gdjs.gameCode.GDCloudObjects2= [];
gdjs.gameCode.GDCloudObjects3= [];
gdjs.gameCode.GDBackgroundObjectsObjects1= [];
gdjs.gameCode.GDBackgroundObjectsObjects2= [];
gdjs.gameCode.GDBackgroundObjectsObjects3= [];
gdjs.gameCode.GDScoreObjects1= [];
gdjs.gameCode.GDScoreObjects2= [];
gdjs.gameCode.GDScoreObjects3= [];
gdjs.gameCode.GDCoinObjects1= [];
gdjs.gameCode.GDCoinObjects2= [];
gdjs.gameCode.GDCoinObjects3= [];
gdjs.gameCode.GDCoinIconObjects1= [];
gdjs.gameCode.GDCoinIconObjects2= [];
gdjs.gameCode.GDCoinIconObjects3= [];
gdjs.gameCode.GDLeftButtonObjects1= [];
gdjs.gameCode.GDLeftButtonObjects2= [];
gdjs.gameCode.GDLeftButtonObjects3= [];
gdjs.gameCode.GDRightButtonObjects1= [];
gdjs.gameCode.GDRightButtonObjects2= [];
gdjs.gameCode.GDRightButtonObjects3= [];
gdjs.gameCode.GDJumpButtonObjects1= [];
gdjs.gameCode.GDJumpButtonObjects2= [];
gdjs.gameCode.GDJumpButtonObjects3= [];
gdjs.gameCode.GDArrowButtonsBgObjects1= [];
gdjs.gameCode.GDArrowButtonsBgObjects2= [];
gdjs.gameCode.GDArrowButtonsBgObjects3= [];
gdjs.gameCode.GDlavetokillObjects1= [];
gdjs.gameCode.GDlavetokillObjects2= [];
gdjs.gameCode.GDlavetokillObjects3= [];
gdjs.gameCode.GDhill1Objects1= [];
gdjs.gameCode.GDhill1Objects2= [];
gdjs.gameCode.GDhill1Objects3= [];
gdjs.gameCode.GDhill2Objects1= [];
gdjs.gameCode.GDhill2Objects2= [];
gdjs.gameCode.GDhill2Objects3= [];
gdjs.gameCode.GDFenceObjects1= [];
gdjs.gameCode.GDFenceObjects2= [];
gdjs.gameCode.GDFenceObjects3= [];
gdjs.gameCode.GDmilitarybaseObjects1= [];
gdjs.gameCode.GDmilitarybaseObjects2= [];
gdjs.gameCode.GDmilitarybaseObjects3= [];
gdjs.gameCode.GDJetObjects1= [];
gdjs.gameCode.GDJetObjects2= [];
gdjs.gameCode.GDJetObjects3= [];
gdjs.gameCode.GDtanks2Objects1= [];
gdjs.gameCode.GDtanks2Objects2= [];
gdjs.gameCode.GDtanks2Objects3= [];
gdjs.gameCode.GDtanksObjects1= [];
gdjs.gameCode.GDtanksObjects2= [];
gdjs.gameCode.GDtanksObjects3= [];
gdjs.gameCode.GDpavementObjects1= [];
gdjs.gameCode.GDpavementObjects2= [];
gdjs.gameCode.GDpavementObjects3= [];
gdjs.gameCode.GDdesertgroundObjects1= [];
gdjs.gameCode.GDdesertgroundObjects2= [];
gdjs.gameCode.GDdesertgroundObjects3= [];
gdjs.gameCode.GDCactusObjects1= [];
gdjs.gameCode.GDCactusObjects2= [];
gdjs.gameCode.GDCactusObjects3= [];
gdjs.gameCode.GDHill3Objects1= [];
gdjs.gameCode.GDHill3Objects2= [];
gdjs.gameCode.GDHill3Objects3= [];

gdjs.gameCode.conditionTrue_0 = {val:false};
gdjs.gameCode.condition0IsTrue_0 = {val:false};
gdjs.gameCode.condition1IsTrue_0 = {val:false};
gdjs.gameCode.condition2IsTrue_0 = {val:false};
gdjs.gameCode.condition3IsTrue_0 = {val:false};
gdjs.gameCode.conditionTrue_1 = {val:false};
gdjs.gameCode.condition0IsTrue_1 = {val:false};
gdjs.gameCode.condition1IsTrue_1 = {val:false};
gdjs.gameCode.condition2IsTrue_1 = {val:false};
gdjs.gameCode.condition3IsTrue_1 = {val:false};


gdjs.gameCode.eventsList0x69b294 = function(runtimeScene) {

{

gdjs.gameCode.GDPlayerHitBoxObjects2.createFrom(gdjs.gameCode.GDPlayerHitBoxObjects1);


gdjs.gameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.gameCode.GDPlayerHitBoxObjects2.length;i<l;++i) {
    if ( !(gdjs.gameCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDPlayerHitBoxObjects2[k] = gdjs.gameCode.GDPlayerHitBoxObjects2[i];
        ++k;
    }
}
gdjs.gameCode.GDPlayerHitBoxObjects2.length = k;}if (gdjs.gameCode.condition0IsTrue_0.val) {
gdjs.gameCode.GDPlayerObjects2.createFrom(runtimeScene.getObjects("Player"));
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects2[i].setAnimation(0);
}
}}

}


{

/* Reuse gdjs.gameCode.GDPlayerHitBoxObjects1 */

gdjs.gameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.gameCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isMoving() ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDPlayerHitBoxObjects1[k] = gdjs.gameCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs.gameCode.condition0IsTrue_0.val) {
gdjs.gameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].setAnimation(2);
}
}}

}


}; //End of gdjs.gameCode.eventsList0x69b294
gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDGoLeftObjects1Objects = Hashtable.newFrom({"GoLeft": gdjs.gameCode.GDGoLeftObjects1});gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDMovingPlatformObjects1Objects = Hashtable.newFrom({"MovingPlatform": gdjs.gameCode.GDMovingPlatformObjects1});gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDGoRightObjects1Objects = Hashtable.newFrom({"GoRight": gdjs.gameCode.GDGoRightObjects1});gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDMovingPlatformObjects1Objects = Hashtable.newFrom({"MovingPlatform": gdjs.gameCode.GDMovingPlatformObjects1});gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDGoLeftObjects1Objects = Hashtable.newFrom({"GoLeft": gdjs.gameCode.GDGoLeftObjects1});gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDSlimeWalkObjects1ObjectsGDgdjs_46gameCode_46GDFlyObjects1Objects = Hashtable.newFrom({"SlimeWalk": gdjs.gameCode.GDSlimeWalkObjects1, "Fly": gdjs.gameCode.GDFlyObjects1});gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDGoRightObjects1Objects = Hashtable.newFrom({"GoRight": gdjs.gameCode.GDGoRightObjects1});gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDSlimeWalkObjects1ObjectsGDgdjs_46gameCode_46GDFlyObjects1Objects = Hashtable.newFrom({"SlimeWalk": gdjs.gameCode.GDSlimeWalkObjects1, "Fly": gdjs.gameCode.GDFlyObjects1});gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDPlayerHitBoxObjects1Objects = Hashtable.newFrom({"PlayerHitBox": gdjs.gameCode.GDPlayerHitBoxObjects1});gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDSlimeWalkObjects1ObjectsGDgdjs_46gameCode_46GDFlyObjects1Objects = Hashtable.newFrom({"SlimeWalk": gdjs.gameCode.GDSlimeWalkObjects1, "Fly": gdjs.gameCode.GDFlyObjects1});gdjs.gameCode.eventsList0x69f99c = function(runtimeScene) {

}; //End of gdjs.gameCode.eventsList0x69f99c
gdjs.gameCode.eventsList0x69f334 = function(runtimeScene) {

{

/* Reuse gdjs.gameCode.GDFlyObjects2 */
/* Reuse gdjs.gameCode.GDSlimeWalkObjects2 */

gdjs.gameCode.forEachTotalCount3 = 0;
gdjs.gameCode.forEachObjects3.length = 0;
gdjs.gameCode.forEachCount0_3 = gdjs.gameCode.GDSlimeWalkObjects2.length;
gdjs.gameCode.forEachTotalCount3 += gdjs.gameCode.forEachCount0_3;
gdjs.gameCode.forEachObjects3.push.apply(gdjs.gameCode.forEachObjects3,gdjs.gameCode.GDSlimeWalkObjects2);
gdjs.gameCode.forEachCount1_3 = gdjs.gameCode.GDFlyObjects2.length;
gdjs.gameCode.forEachTotalCount3 += gdjs.gameCode.forEachCount1_3;
gdjs.gameCode.forEachObjects3.push.apply(gdjs.gameCode.forEachObjects3,gdjs.gameCode.GDFlyObjects2);
for(gdjs.gameCode.forEachIndex3 = 0;gdjs.gameCode.forEachIndex3 < gdjs.gameCode.forEachTotalCount3;++gdjs.gameCode.forEachIndex3) {
gdjs.gameCode.GDFlyObjects3.length = 0;

gdjs.gameCode.GDSlimeWalkObjects3.length = 0;


if (gdjs.gameCode.forEachIndex3 < gdjs.gameCode.forEachCount0_3) {
    gdjs.gameCode.GDSlimeWalkObjects3.push(gdjs.gameCode.forEachObjects3[gdjs.gameCode.forEachIndex3]);
}
else if (gdjs.gameCode.forEachIndex3 < gdjs.gameCode.forEachCount0_3+gdjs.gameCode.forEachCount1_3) {
    gdjs.gameCode.GDFlyObjects3.push(gdjs.gameCode.forEachObjects3[gdjs.gameCode.forEachIndex3]);
}
if (true) {
{runtimeScene.getVariables().getFromIndex(0).add(50);
}}
}

}


}; //End of gdjs.gameCode.eventsList0x69f334
gdjs.gameCode.eventsList0x7739f4 = function(runtimeScene) {

{

gdjs.gameCode.GDPlayerHitBoxObjects2.createFrom(gdjs.gameCode.GDPlayerHitBoxObjects1);


gdjs.gameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.gameCode.GDPlayerHitBoxObjects2.length;i<l;++i) {
    if ( gdjs.gameCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDPlayerHitBoxObjects2[k] = gdjs.gameCode.GDPlayerHitBoxObjects2[i];
        ++k;
    }
}
gdjs.gameCode.GDPlayerHitBoxObjects2.length = k;}if (gdjs.gameCode.condition0IsTrue_0.val) {
gdjs.gameCode.GDFlyObjects2.createFrom(gdjs.gameCode.GDFlyObjects1);

/* Reuse gdjs.gameCode.GDPlayerHitBoxObjects2 */
gdjs.gameCode.GDSlimeWalkObjects2.createFrom(gdjs.gameCode.GDSlimeWalkObjects1);

{for(var i = 0, len = gdjs.gameCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDSlimeWalkObjects2[i].setAnimation(1);
}
for(var i = 0, len = gdjs.gameCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDFlyObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.gameCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDSlimeWalkObjects2[i].activateBehavior("PlatformerObject", true);
}
for(var i = 0, len = gdjs.gameCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDFlyObjects2[i].activateBehavior("PlatformerObject", true);
}
}{for(var i = 0, len = gdjs.gameCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDSlimeWalkObjects2[i].getBehavior("PlatformerObject").setGravity(1500);
}
for(var i = 0, len = gdjs.gameCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDFlyObjects2[i].getBehavior("PlatformerObject").setGravity(1500);
}
}{for(var i = 0, len = gdjs.gameCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.gameCode.GDPlayerHitBoxObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "jump.wav", false, 100, 1);
}
{ //Subevents
gdjs.gameCode.eventsList0x69f334(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.gameCode.GDFlyObjects1 */
/* Reuse gdjs.gameCode.GDPlayerHitBoxObjects1 */
/* Reuse gdjs.gameCode.GDSlimeWalkObjects1 */

gdjs.gameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.gameCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDPlayerHitBoxObjects1[i].getY() >= (( gdjs.gameCode.GDFlyObjects1.length === 0 ) ? (( gdjs.gameCode.GDSlimeWalkObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDSlimeWalkObjects1[0].getPointY("")) :gdjs.gameCode.GDFlyObjects1[0].getPointY("")) - (gdjs.gameCode.GDPlayerHitBoxObjects1[i].getHeight()) + (( gdjs.gameCode.GDFlyObjects1.length === 0 ) ? (( gdjs.gameCode.GDSlimeWalkObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDSlimeWalkObjects1[0].getHeight()) :gdjs.gameCode.GDFlyObjects1[0].getHeight()) / 2 ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDPlayerHitBoxObjects1[k] = gdjs.gameCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs.gameCode.condition0IsTrue_0.val) {
}

}


}; //End of gdjs.gameCode.eventsList0x7739f4
gdjs.gameCode.eventsList0x76deac = function(runtimeScene) {

{

gdjs.gameCode.GDFlyObjects2.createFrom(gdjs.gameCode.GDFlyObjects1);

gdjs.gameCode.GDSlimeWalkObjects2.createFrom(gdjs.gameCode.GDSlimeWalkObjects1);


gdjs.gameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.gameCode.GDSlimeWalkObjects2.length;i<l;++i) {
    if ( gdjs.gameCode.GDSlimeWalkObjects2[i].getVariableNumber(gdjs.gameCode.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")) == 1 ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDSlimeWalkObjects2[k] = gdjs.gameCode.GDSlimeWalkObjects2[i];
        ++k;
    }
}
gdjs.gameCode.GDSlimeWalkObjects2.length = k;for(var i = 0, k = 0, l = gdjs.gameCode.GDFlyObjects2.length;i<l;++i) {
    if ( gdjs.gameCode.GDFlyObjects2[i].getVariableNumber(gdjs.gameCode.GDFlyObjects2[i].getVariables().get("GoingLeft")) == 1 ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDFlyObjects2[k] = gdjs.gameCode.GDFlyObjects2[i];
        ++k;
    }
}
gdjs.gameCode.GDFlyObjects2.length = k;}if (gdjs.gameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.gameCode.GDFlyObjects2 */
/* Reuse gdjs.gameCode.GDSlimeWalkObjects2 */
{for(var i = 0, len = gdjs.gameCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDFlyObjects2[i].addForce(-(300), 0, 0);
}
}{for(var i = 0, len = gdjs.gameCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDSlimeWalkObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
for(var i = 0, len = gdjs.gameCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDFlyObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.gameCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDSlimeWalkObjects2[i].flipX(false);
}
for(var i = 0, len = gdjs.gameCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDFlyObjects2[i].flipX(false);
}
}}

}


{

gdjs.gameCode.GDFlyObjects2.createFrom(gdjs.gameCode.GDFlyObjects1);

gdjs.gameCode.GDSlimeWalkObjects2.createFrom(gdjs.gameCode.GDSlimeWalkObjects1);


gdjs.gameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.gameCode.GDSlimeWalkObjects2.length;i<l;++i) {
    if ( gdjs.gameCode.GDSlimeWalkObjects2[i].getVariableNumber(gdjs.gameCode.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")) == 0 ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDSlimeWalkObjects2[k] = gdjs.gameCode.GDSlimeWalkObjects2[i];
        ++k;
    }
}
gdjs.gameCode.GDSlimeWalkObjects2.length = k;for(var i = 0, k = 0, l = gdjs.gameCode.GDFlyObjects2.length;i<l;++i) {
    if ( gdjs.gameCode.GDFlyObjects2[i].getVariableNumber(gdjs.gameCode.GDFlyObjects2[i].getVariables().get("GoingLeft")) == 0 ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDFlyObjects2[k] = gdjs.gameCode.GDFlyObjects2[i];
        ++k;
    }
}
gdjs.gameCode.GDFlyObjects2.length = k;}if (gdjs.gameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.gameCode.GDFlyObjects2 */
/* Reuse gdjs.gameCode.GDSlimeWalkObjects2 */
{for(var i = 0, len = gdjs.gameCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDFlyObjects2[i].addForce(300, 0, 0);
}
}{for(var i = 0, len = gdjs.gameCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDSlimeWalkObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
for(var i = 0, len = gdjs.gameCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDFlyObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.gameCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDSlimeWalkObjects2[i].flipX(true);
}
for(var i = 0, len = gdjs.gameCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.gameCode.GDFlyObjects2[i].flipX(true);
}
}}

}


{



}


{

/* Reuse gdjs.gameCode.GDFlyObjects1 */
gdjs.gameCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));
/* Reuse gdjs.gameCode.GDSlimeWalkObjects1 */

gdjs.gameCode.condition0IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDPlayerHitBoxObjects1Objects, gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDSlimeWalkObjects1ObjectsGDgdjs_46gameCode_46GDFlyObjects1Objects, false, runtimeScene, false);
}if (gdjs.gameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.gameCode.eventsList0x7739f4(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.gameCode.eventsList0x76deac
gdjs.gameCode.eventsList0x6a3804 = function(runtimeScene) {

{

/* Reuse gdjs.gameCode.GDFlyObjects1 */
/* Reuse gdjs.gameCode.GDSlimeWalkObjects1 */

gdjs.gameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.gameCode.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDSlimeWalkObjects1[i].getOpacity() == 0 ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDSlimeWalkObjects1[k] = gdjs.gameCode.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDSlimeWalkObjects1.length = k;for(var i = 0, k = 0, l = gdjs.gameCode.GDFlyObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDFlyObjects1[i].getOpacity() == 0 ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDFlyObjects1[k] = gdjs.gameCode.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDFlyObjects1.length = k;}if (gdjs.gameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.gameCode.GDFlyObjects1 */
/* Reuse gdjs.gameCode.GDSlimeWalkObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDSlimeWalkObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDSlimeWalkObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.gameCode.GDFlyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDFlyObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


}; //End of gdjs.gameCode.eventsList0x6a3804
gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDPlayerHitBoxObjects1Objects = Hashtable.newFrom({"PlayerHitBox": gdjs.gameCode.GDPlayerHitBoxObjects1});gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDCoinObjects1Objects = Hashtable.newFrom({"Coin": gdjs.gameCode.GDCoinObjects1});gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDLeftButtonObjects1Objects = Hashtable.newFrom({"LeftButton": gdjs.gameCode.GDLeftButtonObjects1});gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDRightButtonObjects1Objects = Hashtable.newFrom({"RightButton": gdjs.gameCode.GDRightButtonObjects1});gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDJumpButtonObjects1Objects = Hashtable.newFrom({"JumpButton": gdjs.gameCode.GDJumpButtonObjects1});gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDlavetokillObjects1Objects = Hashtable.newFrom({"lavetokill": gdjs.gameCode.GDlavetokillObjects1});gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.gameCode.GDPlayerObjects1});gdjs.gameCode.eventsList0xb3ea0 = function(runtimeScene) {

{


gdjs.gameCode.condition0IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.gameCode.condition0IsTrue_0.val) {
gdjs.gameCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));
{for(var i = 0, len = gdjs.gameCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerHitBoxObjects1[i].hide();
}
}}

}


{


{
gdjs.gameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
gdjs.gameCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].setPosition((( gdjs.gameCode.GDPlayerHitBoxObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerHitBoxObjects1[0].getPointX("")) - 12,(( gdjs.gameCode.GDPlayerHitBoxObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerHitBoxObjects1[0].getPointY("")));
}
}}

}


{



}


{

gdjs.gameCode.GDPlayerObjects1.length = 0;


gdjs.gameCode.condition0IsTrue_0.val = false;
gdjs.gameCode.condition1IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
}if ( gdjs.gameCode.condition0IsTrue_0.val ) {
{
{gdjs.gameCode.conditionTrue_1 = gdjs.gameCode.condition1IsTrue_0;
gdjs.gameCode.GDPlayerObjects1_1final.length = 0;gdjs.gameCode.condition0IsTrue_1.val = false;
gdjs.gameCode.condition1IsTrue_1.val = false;
{
gdjs.gameCode.GDPlayerObjects2.createFrom(runtimeScene.getObjects("Player"));
for(var i = 0, k = 0, l = gdjs.gameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.gameCode.GDPlayerObjects2[i].getAnimation() == 0 ) {
        gdjs.gameCode.condition0IsTrue_1.val = true;
        gdjs.gameCode.GDPlayerObjects2[k] = gdjs.gameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.gameCode.GDPlayerObjects2.length = k;if( gdjs.gameCode.condition0IsTrue_1.val ) {
    gdjs.gameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.gameCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.gameCode.GDPlayerObjects1_1final.indexOf(gdjs.gameCode.GDPlayerObjects2[j]) === -1 )
            gdjs.gameCode.GDPlayerObjects1_1final.push(gdjs.gameCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.gameCode.GDPlayerObjects2.createFrom(runtimeScene.getObjects("Player"));
for(var i = 0, k = 0, l = gdjs.gameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.gameCode.GDPlayerObjects2[i].getAnimation() == 2 ) {
        gdjs.gameCode.condition1IsTrue_1.val = true;
        gdjs.gameCode.GDPlayerObjects2[k] = gdjs.gameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.gameCode.GDPlayerObjects2.length = k;if( gdjs.gameCode.condition1IsTrue_1.val ) {
    gdjs.gameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.gameCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.gameCode.GDPlayerObjects1_1final.indexOf(gdjs.gameCode.GDPlayerObjects2[j]) === -1 )
            gdjs.gameCode.GDPlayerObjects1_1final.push(gdjs.gameCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.gameCode.GDPlayerObjects1.createFrom(gdjs.gameCode.GDPlayerObjects1_1final);
}
}
}}
if (gdjs.gameCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "jump.wav", false, 100, 1);
}}

}


{

gdjs.gameCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));

gdjs.gameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.gameCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDPlayerHitBoxObjects1[k] = gdjs.gameCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs.gameCode.condition0IsTrue_0.val) {
gdjs.gameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.gameCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));

gdjs.gameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.gameCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDPlayerHitBoxObjects1[k] = gdjs.gameCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs.gameCode.condition0IsTrue_0.val) {
gdjs.gameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.gameCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));

gdjs.gameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.gameCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDPlayerHitBoxObjects1[k] = gdjs.gameCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs.gameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.gameCode.eventsList0x69b294(runtimeScene);} //End of subevents
}

}


{


gdjs.gameCode.condition0IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.gameCode.condition0IsTrue_0.val) {
gdjs.gameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].flipX(true);
}
}}

}


{


gdjs.gameCode.condition0IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.gameCode.condition0IsTrue_0.val) {
gdjs.gameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].flipX(false);
}
}}

}


{



}


{


{
gdjs.gameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")), "", 0);
}}

}


{



}


{


gdjs.gameCode.condition0IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.gameCode.condition0IsTrue_0.val) {
gdjs.gameCode.GDGoLeftObjects1.createFrom(runtimeScene.getObjects("GoLeft"));
gdjs.gameCode.GDGoRightObjects1.createFrom(runtimeScene.getObjects("GoRight"));
{for(var i = 0, len = gdjs.gameCode.GDGoLeftObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDGoLeftObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.gameCode.GDGoRightObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDGoRightObjects1[i].hide();
}
}}

}


{

gdjs.gameCode.GDGoLeftObjects1.createFrom(runtimeScene.getObjects("GoLeft"));
gdjs.gameCode.GDMovingPlatformObjects1.createFrom(runtimeScene.getObjects("MovingPlatform"));

gdjs.gameCode.condition0IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDGoLeftObjects1Objects, gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDMovingPlatformObjects1Objects, false, runtimeScene, false);
}if (gdjs.gameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.gameCode.GDMovingPlatformObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDMovingPlatformObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.gameCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDMovingPlatformObjects1[i].addForce(-(150), 0, 1);
}
}}

}


{

gdjs.gameCode.GDGoRightObjects1.createFrom(runtimeScene.getObjects("GoRight"));
gdjs.gameCode.GDMovingPlatformObjects1.createFrom(runtimeScene.getObjects("MovingPlatform"));

gdjs.gameCode.condition0IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDGoRightObjects1Objects, gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDMovingPlatformObjects1Objects, false, runtimeScene, false);
}if (gdjs.gameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.gameCode.GDMovingPlatformObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDMovingPlatformObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.gameCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDMovingPlatformObjects1[i].addForce(150, 0, 1);
}
}}

}


{



}


{



}


{


gdjs.gameCode.condition0IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.gameCode.condition0IsTrue_0.val) {
gdjs.gameCode.GDFlyObjects1.createFrom(runtimeScene.getObjects("Fly"));
{for(var i = 0, len = gdjs.gameCode.GDFlyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDFlyObjects1[i].activateBehavior("PlatformerObject", false);
}
}}

}


{



}


{

gdjs.gameCode.GDFlyObjects1.createFrom(runtimeScene.getObjects("Fly"));
gdjs.gameCode.GDGoLeftObjects1.createFrom(runtimeScene.getObjects("GoLeft"));
gdjs.gameCode.GDSlimeWalkObjects1.createFrom(runtimeScene.getObjects("SlimeWalk"));

gdjs.gameCode.condition0IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDGoLeftObjects1Objects, gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDSlimeWalkObjects1ObjectsGDgdjs_46gameCode_46GDFlyObjects1Objects, false, runtimeScene, false);
}if (gdjs.gameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.gameCode.GDFlyObjects1 */
/* Reuse gdjs.gameCode.GDSlimeWalkObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDSlimeWalkObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDSlimeWalkObjects1[i].returnVariable(gdjs.gameCode.GDSlimeWalkObjects1[i].getVariables().get("GoingLeft")).setNumber(1);
}
for(var i = 0, len = gdjs.gameCode.GDFlyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDFlyObjects1[i].returnVariable(gdjs.gameCode.GDFlyObjects1[i].getVariables().get("GoingLeft")).setNumber(1);
}
}}

}


{

gdjs.gameCode.GDFlyObjects1.createFrom(runtimeScene.getObjects("Fly"));
gdjs.gameCode.GDGoRightObjects1.createFrom(runtimeScene.getObjects("GoRight"));
gdjs.gameCode.GDSlimeWalkObjects1.createFrom(runtimeScene.getObjects("SlimeWalk"));

gdjs.gameCode.condition0IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDGoRightObjects1Objects, gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDSlimeWalkObjects1ObjectsGDgdjs_46gameCode_46GDFlyObjects1Objects, false, runtimeScene, false);
}if (gdjs.gameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.gameCode.GDFlyObjects1 */
/* Reuse gdjs.gameCode.GDSlimeWalkObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDSlimeWalkObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDSlimeWalkObjects1[i].returnVariable(gdjs.gameCode.GDSlimeWalkObjects1[i].getVariables().get("GoingLeft")).setNumber(0);
}
for(var i = 0, len = gdjs.gameCode.GDFlyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDFlyObjects1[i].returnVariable(gdjs.gameCode.GDFlyObjects1[i].getVariables().get("GoingLeft")).setNumber(0);
}
}}

}


{

gdjs.gameCode.GDFlyObjects1.createFrom(runtimeScene.getObjects("Fly"));
gdjs.gameCode.GDSlimeWalkObjects1.createFrom(runtimeScene.getObjects("SlimeWalk"));

gdjs.gameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.gameCode.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDSlimeWalkObjects1[i].getAnimation() == 0 ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDSlimeWalkObjects1[k] = gdjs.gameCode.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDSlimeWalkObjects1.length = k;for(var i = 0, k = 0, l = gdjs.gameCode.GDFlyObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDFlyObjects1[i].getAnimation() == 0 ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDFlyObjects1[k] = gdjs.gameCode.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDFlyObjects1.length = k;}if (gdjs.gameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.gameCode.eventsList0x76deac(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.gameCode.GDFlyObjects1.createFrom(runtimeScene.getObjects("Fly"));
gdjs.gameCode.GDSlimeWalkObjects1.createFrom(runtimeScene.getObjects("SlimeWalk"));

gdjs.gameCode.condition0IsTrue_0.val = false;
gdjs.gameCode.condition1IsTrue_0.val = false;
gdjs.gameCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.gameCode.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDSlimeWalkObjects1[i].getAnimation() == 1 ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDSlimeWalkObjects1[k] = gdjs.gameCode.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDSlimeWalkObjects1.length = k;for(var i = 0, k = 0, l = gdjs.gameCode.GDFlyObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDFlyObjects1[i].getAnimation() == 1 ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDFlyObjects1[k] = gdjs.gameCode.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDFlyObjects1.length = k;}if ( gdjs.gameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.gameCode.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDSlimeWalkObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.gameCode.condition1IsTrue_0.val = true;
        gdjs.gameCode.GDSlimeWalkObjects1[k] = gdjs.gameCode.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDSlimeWalkObjects1.length = k;for(var i = 0, k = 0, l = gdjs.gameCode.GDFlyObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDFlyObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.gameCode.condition1IsTrue_0.val = true;
        gdjs.gameCode.GDFlyObjects1[k] = gdjs.gameCode.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDFlyObjects1.length = k;}if ( gdjs.gameCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.gameCode.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( !(gdjs.gameCode.GDSlimeWalkObjects1[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.gameCode.condition2IsTrue_0.val = true;
        gdjs.gameCode.GDSlimeWalkObjects1[k] = gdjs.gameCode.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDSlimeWalkObjects1.length = k;for(var i = 0, k = 0, l = gdjs.gameCode.GDFlyObjects1.length;i<l;++i) {
    if ( !(gdjs.gameCode.GDFlyObjects1[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.gameCode.condition2IsTrue_0.val = true;
        gdjs.gameCode.GDFlyObjects1[k] = gdjs.gameCode.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDFlyObjects1.length = k;}}
}
if (gdjs.gameCode.condition2IsTrue_0.val) {
/* Reuse gdjs.gameCode.GDFlyObjects1 */
/* Reuse gdjs.gameCode.GDSlimeWalkObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDSlimeWalkObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDSlimeWalkObjects1[i].activateBehavior("PlatformerObject", false);
}
for(var i = 0, len = gdjs.gameCode.GDFlyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDFlyObjects1[i].activateBehavior("PlatformerObject", false);
}
}{for(var i = 0, len = gdjs.gameCode.GDSlimeWalkObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDSlimeWalkObjects1[i].setOpacity(gdjs.gameCode.GDSlimeWalkObjects1[i].getOpacity() - (50 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
for(var i = 0, len = gdjs.gameCode.GDFlyObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDFlyObjects1[i].setOpacity(gdjs.gameCode.GDFlyObjects1[i].getOpacity() - (50 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}
{ //Subevents
gdjs.gameCode.eventsList0x6a3804(runtimeScene);} //End of subevents
}

}


{



}


{



}


{

gdjs.gameCode.GDCoinObjects1.createFrom(runtimeScene.getObjects("Coin"));
gdjs.gameCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));

gdjs.gameCode.condition0IsTrue_0.val = false;
gdjs.gameCode.condition1IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDPlayerHitBoxObjects1Objects, gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDCoinObjects1Objects, false, runtimeScene, false);
}if ( gdjs.gameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.gameCode.GDCoinObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDCoinObjects1[i].getOpacity() == 255 ) {
        gdjs.gameCode.condition1IsTrue_0.val = true;
        gdjs.gameCode.GDCoinObjects1[k] = gdjs.gameCode.GDCoinObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDCoinObjects1.length = k;}}
if (gdjs.gameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.gameCode.GDCoinObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDCoinObjects1[i].setOpacity(254);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "coin.wav", false, 100, 1);
}{runtimeScene.getVariables().getFromIndex(0).add(100);
}}

}


{

gdjs.gameCode.GDCoinObjects1.createFrom(runtimeScene.getObjects("Coin"));

gdjs.gameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.gameCode.GDCoinObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDCoinObjects1[i].getOpacity() < 255 ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDCoinObjects1[k] = gdjs.gameCode.GDCoinObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDCoinObjects1.length = k;}if (gdjs.gameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.gameCode.GDCoinObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDCoinObjects1[i].setOpacity(gdjs.gameCode.GDCoinObjects1[i].getOpacity() - (255 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.gameCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDCoinObjects1[i].addForce(0, -(30), 0);
}
}}

}


{

gdjs.gameCode.GDCoinObjects1.createFrom(runtimeScene.getObjects("Coin"));

gdjs.gameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.gameCode.GDCoinObjects1.length;i<l;++i) {
    if ( gdjs.gameCode.GDCoinObjects1[i].getOpacity() == 0 ) {
        gdjs.gameCode.condition0IsTrue_0.val = true;
        gdjs.gameCode.GDCoinObjects1[k] = gdjs.gameCode.GDCoinObjects1[i];
        ++k;
    }
}
gdjs.gameCode.GDCoinObjects1.length = k;}if (gdjs.gameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.gameCode.GDCoinObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDCoinObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{



}


{


{
gdjs.gameCode.GDScoreObjects1.createFrom(runtimeScene.getObjects("Score"));
{for(var i = 0, len = gdjs.gameCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDScoreObjects1[i].setString("x " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0))));
}
}}

}


{



}


{


gdjs.gameCode.condition0IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.isMobile());
}if (gdjs.gameCode.condition0IsTrue_0.val) {
gdjs.gameCode.GDArrowButtonsBgObjects1.createFrom(runtimeScene.getObjects("ArrowButtonsBg"));
gdjs.gameCode.GDJumpButtonObjects1.createFrom(runtimeScene.getObjects("JumpButton"));
gdjs.gameCode.GDLeftButtonObjects1.createFrom(runtimeScene.getObjects("LeftButton"));
gdjs.gameCode.GDRightButtonObjects1.createFrom(runtimeScene.getObjects("RightButton"));
{for(var i = 0, len = gdjs.gameCode.GDLeftButtonObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDLeftButtonObjects1[i].hide();
}
for(var i = 0, len = gdjs.gameCode.GDRightButtonObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDRightButtonObjects1[i].hide();
}
for(var i = 0, len = gdjs.gameCode.GDJumpButtonObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDJumpButtonObjects1[i].hide();
}
for(var i = 0, len = gdjs.gameCode.GDArrowButtonsBgObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDArrowButtonsBgObjects1[i].hide();
}
}}

}


{


gdjs.gameCode.condition0IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.gameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.input.touchSimulateMouse(runtimeScene, false);
}}

}


{

gdjs.gameCode.GDLeftButtonObjects1.createFrom(runtimeScene.getObjects("LeftButton"));

gdjs.gameCode.condition0IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDLeftButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.gameCode.condition0IsTrue_0.val) {
gdjs.gameCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));
{for(var i = 0, len = gdjs.gameCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{

gdjs.gameCode.GDRightButtonObjects1.createFrom(runtimeScene.getObjects("RightButton"));

gdjs.gameCode.condition0IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDRightButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.gameCode.condition0IsTrue_0.val) {
gdjs.gameCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));
{for(var i = 0, len = gdjs.gameCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.gameCode.GDJumpButtonObjects1.createFrom(runtimeScene.getObjects("JumpButton"));

gdjs.gameCode.condition0IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDJumpButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.gameCode.condition0IsTrue_0.val) {
gdjs.gameCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));
{for(var i = 0, len = gdjs.gameCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.gameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
gdjs.gameCode.GDlavetokillObjects1.createFrom(runtimeScene.getObjects("lavetokill"));

gdjs.gameCode.condition0IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDlavetokillObjects1Objects, gdjs.gameCode.mapOfGDgdjs_46gameCode_46GDPlayerObjects1Objects, false, runtimeScene, false);
}if (gdjs.gameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.gameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "title", false);
}}

}


{


{
gdjs.gameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")) * 0.6, "forground", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")) * 0.5, "background", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")) * 0.3, "background2", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")) * 0.2, "background3", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")) * 0.1, "background4pavement", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")) * 0.05, "background5", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")) * 1.2, "frontlayer", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.gameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.gameCode.GDPlayerObjects1[0].getPointX("")) * 1.5, "frontlayer1", 0);
}}

}


{


gdjs.gameCode.condition0IsTrue_0.val = false;
{
gdjs.gameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.gameCode.condition0IsTrue_0.val) {
gdjs.gameCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
{for(var i = 0, len = gdjs.gameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.gameCode.GDPlayerObjects1[i].setX(1);
}
}}

}


}; //End of gdjs.gameCode.eventsList0xb3ea0


gdjs.gameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.gameCode.GDPlayerObjects1.length = 0;
gdjs.gameCode.GDPlayerObjects2.length = 0;
gdjs.gameCode.GDPlayerObjects3.length = 0;
gdjs.gameCode.GDPlatformObjects1.length = 0;
gdjs.gameCode.GDPlatformObjects2.length = 0;
gdjs.gameCode.GDPlatformObjects3.length = 0;
gdjs.gameCode.GDJumpthruObjects1.length = 0;
gdjs.gameCode.GDJumpthruObjects2.length = 0;
gdjs.gameCode.GDJumpthruObjects3.length = 0;
gdjs.gameCode.GDTiledGrassPlatformObjects1.length = 0;
gdjs.gameCode.GDTiledGrassPlatformObjects2.length = 0;
gdjs.gameCode.GDTiledGrassPlatformObjects3.length = 0;
gdjs.gameCode.GDTiledCastlePlatformObjects1.length = 0;
gdjs.gameCode.GDTiledCastlePlatformObjects2.length = 0;
gdjs.gameCode.GDTiledCastlePlatformObjects3.length = 0;
gdjs.gameCode.GDMovingPlatformObjects1.length = 0;
gdjs.gameCode.GDMovingPlatformObjects2.length = 0;
gdjs.gameCode.GDMovingPlatformObjects3.length = 0;
gdjs.gameCode.GDGoLeftObjects1.length = 0;
gdjs.gameCode.GDGoLeftObjects2.length = 0;
gdjs.gameCode.GDGoLeftObjects3.length = 0;
gdjs.gameCode.GDGoRightObjects1.length = 0;
gdjs.gameCode.GDGoRightObjects2.length = 0;
gdjs.gameCode.GDGoRightObjects3.length = 0;
gdjs.gameCode.GDLadderObjects1.length = 0;
gdjs.gameCode.GDLadderObjects2.length = 0;
gdjs.gameCode.GDLadderObjects3.length = 0;
gdjs.gameCode.GDPlayerHitBoxObjects1.length = 0;
gdjs.gameCode.GDPlayerHitBoxObjects2.length = 0;
gdjs.gameCode.GDPlayerHitBoxObjects3.length = 0;
gdjs.gameCode.GDSlimeWalkObjects1.length = 0;
gdjs.gameCode.GDSlimeWalkObjects2.length = 0;
gdjs.gameCode.GDSlimeWalkObjects3.length = 0;
gdjs.gameCode.GDFlyObjects1.length = 0;
gdjs.gameCode.GDFlyObjects2.length = 0;
gdjs.gameCode.GDFlyObjects3.length = 0;
gdjs.gameCode.GDCloudObjects1.length = 0;
gdjs.gameCode.GDCloudObjects2.length = 0;
gdjs.gameCode.GDCloudObjects3.length = 0;
gdjs.gameCode.GDBackgroundObjectsObjects1.length = 0;
gdjs.gameCode.GDBackgroundObjectsObjects2.length = 0;
gdjs.gameCode.GDBackgroundObjectsObjects3.length = 0;
gdjs.gameCode.GDScoreObjects1.length = 0;
gdjs.gameCode.GDScoreObjects2.length = 0;
gdjs.gameCode.GDScoreObjects3.length = 0;
gdjs.gameCode.GDCoinObjects1.length = 0;
gdjs.gameCode.GDCoinObjects2.length = 0;
gdjs.gameCode.GDCoinObjects3.length = 0;
gdjs.gameCode.GDCoinIconObjects1.length = 0;
gdjs.gameCode.GDCoinIconObjects2.length = 0;
gdjs.gameCode.GDCoinIconObjects3.length = 0;
gdjs.gameCode.GDLeftButtonObjects1.length = 0;
gdjs.gameCode.GDLeftButtonObjects2.length = 0;
gdjs.gameCode.GDLeftButtonObjects3.length = 0;
gdjs.gameCode.GDRightButtonObjects1.length = 0;
gdjs.gameCode.GDRightButtonObjects2.length = 0;
gdjs.gameCode.GDRightButtonObjects3.length = 0;
gdjs.gameCode.GDJumpButtonObjects1.length = 0;
gdjs.gameCode.GDJumpButtonObjects2.length = 0;
gdjs.gameCode.GDJumpButtonObjects3.length = 0;
gdjs.gameCode.GDArrowButtonsBgObjects1.length = 0;
gdjs.gameCode.GDArrowButtonsBgObjects2.length = 0;
gdjs.gameCode.GDArrowButtonsBgObjects3.length = 0;
gdjs.gameCode.GDlavetokillObjects1.length = 0;
gdjs.gameCode.GDlavetokillObjects2.length = 0;
gdjs.gameCode.GDlavetokillObjects3.length = 0;
gdjs.gameCode.GDhill1Objects1.length = 0;
gdjs.gameCode.GDhill1Objects2.length = 0;
gdjs.gameCode.GDhill1Objects3.length = 0;
gdjs.gameCode.GDhill2Objects1.length = 0;
gdjs.gameCode.GDhill2Objects2.length = 0;
gdjs.gameCode.GDhill2Objects3.length = 0;
gdjs.gameCode.GDFenceObjects1.length = 0;
gdjs.gameCode.GDFenceObjects2.length = 0;
gdjs.gameCode.GDFenceObjects3.length = 0;
gdjs.gameCode.GDmilitarybaseObjects1.length = 0;
gdjs.gameCode.GDmilitarybaseObjects2.length = 0;
gdjs.gameCode.GDmilitarybaseObjects3.length = 0;
gdjs.gameCode.GDJetObjects1.length = 0;
gdjs.gameCode.GDJetObjects2.length = 0;
gdjs.gameCode.GDJetObjects3.length = 0;
gdjs.gameCode.GDtanks2Objects1.length = 0;
gdjs.gameCode.GDtanks2Objects2.length = 0;
gdjs.gameCode.GDtanks2Objects3.length = 0;
gdjs.gameCode.GDtanksObjects1.length = 0;
gdjs.gameCode.GDtanksObjects2.length = 0;
gdjs.gameCode.GDtanksObjects3.length = 0;
gdjs.gameCode.GDpavementObjects1.length = 0;
gdjs.gameCode.GDpavementObjects2.length = 0;
gdjs.gameCode.GDpavementObjects3.length = 0;
gdjs.gameCode.GDdesertgroundObjects1.length = 0;
gdjs.gameCode.GDdesertgroundObjects2.length = 0;
gdjs.gameCode.GDdesertgroundObjects3.length = 0;
gdjs.gameCode.GDCactusObjects1.length = 0;
gdjs.gameCode.GDCactusObjects2.length = 0;
gdjs.gameCode.GDCactusObjects3.length = 0;
gdjs.gameCode.GDHill3Objects1.length = 0;
gdjs.gameCode.GDHill3Objects2.length = 0;
gdjs.gameCode.GDHill3Objects3.length = 0;

gdjs.gameCode.eventsList0xb3ea0(runtimeScene);
return;

}
gdjs['gameCode'] = gdjs.gameCode;
