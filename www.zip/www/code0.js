gdjs.titleCode = {};
gdjs.titleCode.GDStartObjects1= [];
gdjs.titleCode.GDStartObjects2= [];

gdjs.titleCode.conditionTrue_0 = {val:false};
gdjs.titleCode.condition0IsTrue_0 = {val:false};
gdjs.titleCode.condition1IsTrue_0 = {val:false};
gdjs.titleCode.condition2IsTrue_0 = {val:false};


gdjs.titleCode.mapOfGDgdjs_46titleCode_46GDStartObjects1Objects = Hashtable.newFrom({"Start": gdjs.titleCode.GDStartObjects1});gdjs.titleCode.eventsList0xb3ea0 = function(runtimeScene) {

{

gdjs.titleCode.GDStartObjects1.createFrom(runtimeScene.getObjects("Start"));

gdjs.titleCode.condition0IsTrue_0.val = false;
gdjs.titleCode.condition1IsTrue_0.val = false;
{
gdjs.titleCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.titleCode.mapOfGDgdjs_46titleCode_46GDStartObjects1Objects, runtimeScene, true, false);
}if ( gdjs.titleCode.condition0IsTrue_0.val ) {
{
gdjs.titleCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.titleCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "game", false);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "game", false);
}}

}


}; //End of gdjs.titleCode.eventsList0xb3ea0


gdjs.titleCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.titleCode.GDStartObjects1.length = 0;
gdjs.titleCode.GDStartObjects2.length = 0;

gdjs.titleCode.eventsList0xb3ea0(runtimeScene);
return;

}
gdjs['titleCode'] = gdjs.titleCode;
